import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import calendar
import os

data = pd.read_csv('BreadBasket_DMS.csv')

Top=data['Item'].value_counts()
print(Top.head(10))
data.dropna()
data = data[data['Item'] != 'NONE']
data['Date'] = pd.to_datetime(data['Date'])
data['Time'] = pd.to_datetime(data['Time'])
data['Year'] = data['Date'].dt.year
data['Month'] = data['Date'].dt.month
data['Day'] = data['Date'].dt.day
data['Weekday'] = data['Date'].dt.weekday
data['Hour'] = data['Time'].dt.hour
data['Year'] = data['Date'].dt.year

def map_indexes_and_values(df, col):
    df_col = df[col].value_counts()
    x = df_col.index.tolist()
    y = df_col.values.tolist()
    return x, y

weekmap = {0:'Mon', 1:'Tue', 2:'Wed', 3:'Thu', 4:'Fri', 5:'Sat', 6:'Sun'}

popular_items, popular_items_count = map_indexes_and_values(data, 'Item')
plt.bar(popular_items[:10], popular_items_count[:10])
plt.xlabel('Most popular Items')
plt.ylabel('Number of Transactions')
plt.show()